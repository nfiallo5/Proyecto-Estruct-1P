package ec.edu.espol.agenda.model;

import java.io.Serializable;

public class Direccion implements Serializable {
    private String direccion;
    private String descripcion;
    private static final long serialVersionUID = 1L;

    public Direccion(String direccion, String descripcion) {
        this.direccion = direccion;
        this.descripcion = descripcion;
    }

    public String getDireccion() { return direccion; }

    public String getDescripcion() { return descripcion; }
}
