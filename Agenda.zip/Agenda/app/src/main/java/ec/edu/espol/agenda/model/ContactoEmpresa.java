package ec.edu.espol.agenda.model;

public class ContactoEmpresa extends Contacto {
    private String rol;
    private String empresa;

    public ContactoEmpresa() { super(); }

    public String getRol() { return rol; }

    public void setRol(String rol) { this.rol = rol; }

    public String getEmpresa() { return empresa; }

    public void setEmpresa(String empresa) { this.empresa = empresa; }

    @Override
    public String getTipo() { return "Empresa"; }

    @Override
    public int compareTo(Contacto o) { return this.getNombre().compareToIgnoreCase(o.getNombre()); }
}
