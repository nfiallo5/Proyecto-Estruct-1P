package ec.edu.espol.agenda.model;

import java.io.Serializable;

public class Fecha implements Serializable {
    private String fecha;
    private String descripcion;
    private static final long serialVersionUID = 1L;

    public Fecha(String descripcion, String fecha) {
        this.descripcion = descripcion;
        this.fecha = fecha;
    }

    public String getFecha() { return fecha; }

    public String getDescripcion() { return descripcion; }
}
