package ec.edu.espol.agenda.model;

import java.io.Serializable;
import ec.edu.espol.agenda.data.MiArrayList;

public abstract class Contacto implements Serializable, Comparable<Contacto> {
    private static int contador = 0;
    private int id;
    private String nombre;
    private String foto;
    private MiArrayList<Numero> numeros;
    private MiArrayList<Email> correos;
    private MiArrayList<Direccion> direcciones;

    public Contacto() {
        this.id = ++contador;
        this.numeros = new MiArrayList<>();
        this.correos = new MiArrayList<>();
        this.direcciones = new MiArrayList<>();
    }

    public int getId() { return id; }

    public String getNombre() { return nombre; }

    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getFoto() { return foto; }

    public void setFoto(String foto) { this.foto = foto; }

    public MiArrayList<Numero> getNumeros() { return numeros; }

    public void setNumeros(MiArrayList<Numero> numeros) { this.numeros = numeros; }

    public MiArrayList<Email> getCorreos() { return correos; }

    public void setCorreos(MiArrayList<Email> correos) { this.correos = correos; }

    public MiArrayList<Direccion> getDirecciones() { return direcciones; }

    public void setDirecciones(MiArrayList<Direccion> direcciones) { this.direcciones = direcciones; }

    public abstract String getTipo();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Contacto contacto = (Contacto) obj;
        return this.getId() == contacto.getId();
    }

    @Override
    public int compareTo(Contacto c2){ return this.getClass().getName().compareTo(c2.getClass().getName()); }

    public Integer getCantidadAtributos(){ return numeros.size() + correos.size() + direcciones.size(); }
}

