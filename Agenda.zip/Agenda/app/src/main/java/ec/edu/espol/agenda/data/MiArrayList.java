package ec.edu.espol.agenda.data;


import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class MiArrayList<E> implements Serializable, Iterable<E>, List<E> {
    private static final long serialVersionUID = 1L;

    private int size = 0;
    private E[] array;
    private int capacity = 10;

    @SuppressWarnings("unchecked")
    public MiArrayList() {
        array = (E[]) new Object[capacity];
    }

    public boolean add(E element) {
        if (size == capacity) expandirCapacidad();
        array[size++] = element;
        return true;
    }

    public void addAll(List<E> lista){
        for(int i = 0; i < lista.size(); i++){
            E dato = lista.get(i);
            this.add(dato);
        }
    }

    public void addAll(Queue<E> contactosQueue){
        for(int i = 0; i < contactosQueue.size(); i++){
            E dato = contactosQueue.poll();
            this.add(dato);
        }
    }

    public void replace(List<E> lista){
        this.removeAll();
        this.addAll(lista);
    }

    public void sort(PriorityQueue<E> queue){
        for(int i = 0; i < queue.size(); i++){
            queue.add(array[i]);
        }
        for(int i = 0; i < queue.size(); i++){
            array[i] = queue.poll();
        }
    }

    public void add(int index, E element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException("Índice fuera de rango");
        if (size == capacity) expandirCapacidad();
        System.arraycopy(array, index, array, index + 1, size - index);
        array[index] = element;
        size++;
    }

    public E remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Índice fuera de rango");
        E removedElement = array[index];
        System.arraycopy(array, index + 1, array, index, size - index - 1);
        array[--size] = null;
        return removedElement;
    }

    @Override
    public boolean remove(Object element){
        for (int i = 0; i < size; i++)
            if (array[i].equals(element)){
                remove(i);
                return true;
            }
        return false;
    }

    public void removeAll(){
        for(int i = 0; i < size; i++){
            array[i] = null;
        }
        size = 0;
    }

    public E get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Índice fuera de rango");
        return array[index];
    }

    public E set(int index, E element) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Índice fuera de rango");
        E oldValue = array[index];
        array[index] = element;
        return oldValue;
    }

    public boolean contains(Object element) {
        for (int i = 0; i < size; i++) if (array[i].equals(element)) return true;
        return false;
    }

    public int size() { return size; }

    public boolean isEmpty() { return size == 0;}

    @SuppressWarnings("unchecked")
    private void expandirCapacidad() {
        capacity = capacity + (capacity / 2);
        E[] newArray = (E[]) new Object[capacity];
        System.arraycopy(array, 0, newArray, 0, size);
        array = newArray;
    }

    public void clear() {
        for (int i = 0; i < size; i++) array[i] = null;
        size = 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new MiArrayListIterator();
    }

    private class MiArrayListIterator implements Iterator<E> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            return currentIndex < size;
        }

        @Override
        public E next() {
            if (!hasNext()) throw new IllegalStateException("No hay más elementos");
            return array[currentIndex++];
        }

        @Override
        public void remove() {
            if (currentIndex <= 0) throw new IllegalStateException("No hay elementos para eliminar");
            MiArrayList.this.remove(--currentIndex);
        }
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addAll'");
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addAll'");
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'containsAll'");
    }

    @Override
    public int indexOf(Object o) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'indexOf'");
    }

    @Override
    public int lastIndexOf(Object o) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'lastIndexOf'");
    }

    @Override
    public ListIterator<E> listIterator() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listIterator'");
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listIterator'");
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'removeAll'");
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'retainAll'");
    }

    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'subList'");
    }

    @Override
    public Object[] toArray() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'toArray'");
    }

    @Override
    public <T> T[] toArray(T[] arg0) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'toArray'");
    }
}

