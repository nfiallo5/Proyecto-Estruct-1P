package ec.edu.espol.agenda.view;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import ec.edu.espol.agenda.R;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.*;
import android.text.InputType;
import android.widget.*;
import java.util.function.BiFunction;

public class ContactFormActivity extends AppCompatActivity {

    private EditText etNombre, etApellido, etEmpresa, etRol;
    private TextView tvFecha;
    private Spinner spinnerTipo;
    private LinearLayout layoutNumeros, layoutEmails, layoutDirecciones, layoutFechas, layoutPersonal, layoutEmpresa;
    private Button btnGuardar, btnAgregarNumero, btnAgregarEmail, btnAgregarDireccion, btnAgregarFecha, btnFoto;
    private ImageView ivFoto;
    private Uri fotoUri;

    private MiArrayList<Numero> numeros = new MiArrayList<>();
    private MiArrayList<Email> correos = new MiArrayList<>();
    private MiArrayList<Direccion> direcciones = new MiArrayList<>();
    private MiArrayList<Fecha> fechas = new MiArrayList<>();

    private ContactManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_form);

        ivFoto = findViewById(R.id.ivFoto);
        ivFoto.setImageResource(android.R.drawable.ic_menu_camera);
        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etEmpresa = findViewById(R.id.etEmpresa);
        etRol = findViewById(R.id.etRol);
        spinnerTipo = findViewById(R.id.spinnerTipo);
        layoutNumeros = findViewById(R.id.layoutNumeros);
        layoutEmails = findViewById(R.id.layoutEmails);
        layoutDirecciones = findViewById(R.id.layoutDirecciones);
        layoutFechas = findViewById(R.id.layoutFechas);
        layoutPersonal = findViewById(R.id.layoutPersonal);
        layoutEmpresa = findViewById(R.id.layoutEmpresa);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnAgregarNumero = findViewById(R.id.btnAgregarNumero);
        btnAgregarEmail = findViewById(R.id.btnAgregarEmail);
        btnAgregarDireccion = findViewById(R.id.btnAgregarDireccion);
        btnAgregarFecha = findViewById(R.id.btnAgregarFecha);
        btnFoto = findViewById(R.id.btnFoto);
        ivFoto = findViewById(R.id.ivFoto);
        tvFecha = findViewById(R.id.tvFechas);

        manager = ContactManager.getInstance();

        btnAgregarNumero.setOnClickListener(v -> agregarCampoDinamico(layoutNumeros, "Número"));
        btnAgregarEmail.setOnClickListener(v -> agregarCampoDinamico(layoutEmails, "Correo Electrónico"));
        btnAgregarDireccion.setOnClickListener(v -> agregarCampoDinamico(layoutDirecciones, "Dirección"));
        btnAgregarFecha.setOnClickListener(v -> agregarCampoDinamico(layoutFechas, "Fecha"));
        btnFoto.setOnClickListener(v -> abrirGaleria());
        btnGuardar.setOnClickListener(v -> guardarContacto());

        spinnerTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                actualizarCampos(spinnerTipo.getSelectedItem().toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void actualizarCampos(String tipo) {
        if ("Personal".equals(tipo)) {
            layoutPersonal.setVisibility(View.VISIBLE);
            layoutFechas.setVisibility(View.VISIBLE);
            btnAgregarFecha.setVisibility(View.VISIBLE);
            tvFecha.setVisibility(View.VISIBLE);
        } else {
            layoutPersonal.setVisibility(View.GONE);
            layoutFechas.setVisibility(View.GONE);
            btnAgregarFecha.setVisibility(View.GONE);
            tvFecha.setVisibility(View.GONE);
        }
        layoutEmpresa.setVisibility("Empresa".equals(tipo) ? View.VISIBLE : View.GONE);
    }

    private void agregarCampoDinamico(LinearLayout layout, String hint) {
        LinearLayout campoLayout = new LinearLayout(this);
        campoLayout.setOrientation(LinearLayout.HORIZONTAL);

        EditText etCampo = new EditText(this);
        etCampo.setHint(hint);
        etCampo.setTag("etCampo");
        etCampo.setInputType(hint.equals("Número") ? InputType.TYPE_CLASS_PHONE : (hint.equals("Fecha") ? InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE : InputType.TYPE_CLASS_TEXT));
        etCampo.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        campoLayout.addView(etCampo);

        EditText etDescripcion = new EditText(this);
        etDescripcion.setHint("Descripción");
        etDescripcion.setTag("etDescripcion");
        etDescripcion.setInputType(InputType.TYPE_CLASS_TEXT);
        etDescripcion.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        campoLayout.addView(etDescripcion);

        Button btnEliminar = new Button(this);
        btnEliminar.setText("X");
        btnEliminar.setOnClickListener(v -> layout.removeView(campoLayout));
        campoLayout.addView(btnEliminar);

        layout.addView(campoLayout);
    }

    private <T> void sincronizarListaConVistas(LinearLayout layout, MiArrayList<T> lista, BiFunction<String, String, T> constructor) {
        lista.clear();
        for (int i = 0; i < layout.getChildCount(); i++) {
            View view = layout.getChildAt(i);
            if (view instanceof LinearLayout) {
                EditText etCampo = view.findViewWithTag("etCampo");
                EditText etDescripcion = view.findViewWithTag("etDescripcion");
                if (etCampo != null && etDescripcion != null) {
                    String valorCampo = etCampo.getText().toString().trim();
                    String valorDescripcion = etDescripcion.getText().toString().trim();
                    if (!valorCampo.isEmpty() || !valorDescripcion.isEmpty()) {
                        T elemento = constructor.apply(valorCampo, valorDescripcion);
                        lista.add(elemento);
                    }
                }
            }
        }
    }

    private void guardarContacto() {
        if (etNombre.getText().toString().isEmpty()) {
            Toast.makeText(this, "El nombre es obligatorio.", Toast.LENGTH_SHORT).show();
            return;
        }

        sincronizarListaConVistas(layoutNumeros, numeros, Numero::new);
        sincronizarListaConVistas(layoutEmails, correos, Email::new);
        sincronizarListaConVistas(layoutDirecciones, direcciones, Direccion::new);
        sincronizarListaConVistas(layoutFechas, fechas, Fecha::new);

        String tipo = spinnerTipo.getSelectedItem().toString();
        String foto = (fotoUri != null) ? fotoUri.toString() : "";

        if ("Personal".equals(tipo)) {
            ContactoPersonal contacto = new ContactoPersonal();
            contacto.setNombre(etNombre.getText().toString());
            contacto.setApellido(etApellido.getText().toString());
            contacto.setFoto(foto);
            contacto.setNumeros(numeros);
            contacto.setCorreos(correos);
            contacto.setDirecciones(direcciones);
            contacto.setFechas(fechas);
            manager.agregarContacto(contacto);
        } else if ("Empresa".equals(tipo)) {
            ContactoEmpresa contacto = new ContactoEmpresa();
            contacto.setNombre(etNombre.getText().toString());
            contacto.setEmpresa(etEmpresa.getText().toString());
            contacto.setRol(etRol.getText().toString());
            contacto.setFoto(foto);
            contacto.setNumeros(numeros);
            contacto.setCorreos(correos);
            contacto.setDirecciones(direcciones);
            manager.agregarContacto(contacto);
        } else {
            Toast.makeText(this, "Selecciona un tipo de contacto válido.", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Contacto guardado exitosamente.", Toast.LENGTH_SHORT).show();
        finish();
    }


    private void abrirGaleria() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galeriaLauncher.launch(intent);
    }

    private final ActivityResultLauncher<Intent> galeriaLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    fotoUri = result.getData().getData();
                    mostrarImagenSeleccionada(fotoUri);
                }
            }
    );

    private void mostrarImagenSeleccionada(Uri uri) {
        if (uri != null) {
            ivFoto.setImageURI(uri);
        } else {
            ivFoto.setImageResource(android.R.drawable.ic_menu_camera);
        }
    }
}