package ec.edu.espol.agenda.view;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import ec.edu.espol.agenda.R;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.*;

public class ContactDetailActivity extends AppCompatActivity {

    private ImageView ivFoto;
    private TextView tvTipo, tvNombre, tvApellido, tvEmpresa, tvRol;
    private TextView tvFechasTitulo;
    private LinearLayout layoutNumeros, layoutEmails, layoutDirecciones, layoutFechas, layoutPersonal, layoutEmpresa;
    private Button btnEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        ivFoto = findViewById(R.id.ivFoto);
        tvTipo = findViewById(R.id.tvTipo);
        tvNombre = findViewById(R.id.tvNombre);
        tvApellido = findViewById(R.id.tvApellido);
        tvEmpresa = findViewById(R.id.tvEmpresa);
        tvRol = findViewById(R.id.tvRol);
        layoutNumeros = findViewById(R.id.layoutNumeros);
        layoutEmails = findViewById(R.id.layoutEmails);
        layoutDirecciones = findViewById(R.id.layoutDirecciones);
        layoutFechas = findViewById(R.id.layoutFechas);
        layoutPersonal = findViewById(R.id.layoutPersonal);
        layoutEmpresa = findViewById(R.id.layoutEmpresa);
        btnEditar = findViewById(R.id.btnEditar);
        tvFechasTitulo = findViewById(R.id.tvFechasTitulo);

        Contacto contacto = ContactManager.getInstance().getContactoActual();
        mostrarInformacionContacto(contacto);

        btnEditar.setOnClickListener(v -> {
            ContactManager.getInstance().setContactoActual(contacto);
            Intent intent = new Intent(ContactDetailActivity.this, EditContactActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Contacto contactoActual = ContactManager.getInstance().getContactoActual();
        mostrarInformacionContacto(contactoActual);
    }

    private void mostrarInformacionContacto(Contacto contacto) {
        tvTipo.setText(contacto instanceof ContactoPersonal ? "Personal" : "Empresa");
        tvNombre.setText(contacto.getNombre() != null && !contacto.getNombre().isEmpty() ? contacto.getNombre() : "Aún no definido");

        if (contacto.getFoto() != null) {
            ivFoto.setImageURI(Uri.parse(contacto.getFoto()));
        } else {
            ivFoto.setImageResource(android.R.drawable.ic_menu_camera);
        }

        actualizarVistaDinamica(layoutNumeros, contacto.getNumeros());
        actualizarVistaDinamica(layoutEmails, contacto.getCorreos());
        actualizarVistaDinamica(layoutDirecciones, contacto.getDirecciones());

        if (contacto instanceof ContactoPersonal) {
            ContactoPersonal personal = (ContactoPersonal) contacto;
            layoutPersonal.setVisibility(View.VISIBLE);
            layoutEmpresa.setVisibility(View.GONE);
            layoutFechas.setVisibility(View.VISIBLE);
            tvFechasTitulo.setVisibility(View.VISIBLE);
            tvApellido.setText(!personal.getApellido().isEmpty() ? personal.getApellido() : "Aún no definido");
            actualizarVistaDinamica(layoutFechas, personal.getFechas());
        } else if (contacto instanceof ContactoEmpresa) {
            ContactoEmpresa empresa = (ContactoEmpresa) contacto;
            layoutPersonal.setVisibility(View.GONE);
            layoutEmpresa.setVisibility(View.VISIBLE);
            layoutFechas.setVisibility(View.GONE);
            tvFechasTitulo.setVisibility(View.GONE);
            tvEmpresa.setText(!empresa.getEmpresa().isEmpty() ? empresa.getEmpresa() : "Aún no definido");
            tvRol.setText(!empresa.getRol().isEmpty() ? empresa.getRol() : "Aún no definido");
        }
    }

    private <T> void actualizarVistaDinamica(LinearLayout layout, MiArrayList<T> lista) {
        layout.removeAllViews();
        if (lista == null || lista.isEmpty()) {
            TextView emptyView = new TextView(this);
            emptyView.setText("Aún no definido");
            layout.addView(emptyView);
            return;
        }
        for (T item : lista) {
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            itemLayout.setPadding(0, 8, 0, 8);

            TextView tvCampoPrincipal = new TextView(this);
            tvCampoPrincipal.setText(obtenerTextoCampoPrincipal(item));
            tvCampoPrincipal.setTypeface(null, Typeface.BOLD);
            tvCampoPrincipal.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            itemLayout.addView(tvCampoPrincipal);

            TextView tvDescripcion = new TextView(this);
            tvDescripcion.setText(obtenerTextoDescripcion(item));
            tvDescripcion.setTextSize(12);
            tvDescripcion.setTypeface(null, Typeface.ITALIC);
            tvDescripcion.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            itemLayout.addView(tvDescripcion);

            layout.addView(itemLayout);
        }
    }

    private String obtenerTextoCampoPrincipal(Object item) {
        if (item instanceof Numero) return ((Numero) item).getNumero();
        if (item instanceof Email) return ((Email) item).getEmail();
        if (item instanceof Direccion) return ((Direccion) item).getDireccion();
        if (item instanceof Fecha) return ((Fecha) item).getFecha();
        return null;
    }

    private String obtenerTextoDescripcion(Object item) {
        if (item instanceof Numero) return ((Numero) item).getDescripcion();
        if (item instanceof Email) return ((Email) item).getDescripcion();
        if (item instanceof Direccion) return ((Direccion) item).getDescripcion();
        if (item instanceof Fecha) return ((Fecha) item).getDescripcion();
        return null;
    }
}