package ec.edu.espol.agenda.model;

import java.io.Serializable;

public class Numero implements Serializable {
    private String numero;
    private String descripcion;
    private static final long serialVersionUID = 1L;

    public Numero(String numero, String descripcion) {
        this.numero = numero;
        this.descripcion = descripcion;
    }

    public String getNumero() { return numero; }

    public String getDescripcion() { return descripcion; }
}

