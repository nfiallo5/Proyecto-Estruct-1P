package ec.edu.espol.agenda.controller;

import ec.edu.espol.agenda.model.ContactManager;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.Contacto;

public class MainController {

    private ContactManager contactoManager;

    public MainController() {
        this.contactoManager = ContactManager.getInstance();
    }

    public MiArrayList<Contacto> obtenerContactosOrdenadosPorNombre() {
        return contactoManager.ordenarPorNombre();
    }

    public MiArrayList<Contacto> obtenerContactosOrdenadosPorTipo(boolean descendente) {
        return contactoManager.ordenarPorTipo(descendente);
    }

    public MiArrayList<Contacto> obtenerContactosOrdenadosPorAtributos() {
        return contactoManager.ordenarPorCantidadAtributos();
    }
}