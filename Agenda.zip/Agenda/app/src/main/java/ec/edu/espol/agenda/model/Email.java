package ec.edu.espol.agenda.model;

import java.io.Serializable;

public class Email implements Serializable {
    private String email;
    private String descripcion;
    private static final long serialVersionUID = 1L;

    public Email(String email, String descripcion) {
        this.email = email;
        this.descripcion = descripcion;
    }

    public String getEmail() { return email; }

    public String getDescripcion() { return descripcion; }
}

