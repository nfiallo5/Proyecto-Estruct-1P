package ec.edu.espol.agenda.view;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ec.edu.espol.agenda.R;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.*;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactViewHolder> {

    private MiArrayList<Contacto> contactos;
    private OnContactDeleteListener deleteListener;
    private boolean mostrarBotonesEliminar = false;

    public ContactAdapter(MiArrayList<Contacto> contactos, OnContactDeleteListener deleteListener) {
        this.contactos = contactos != null ? contactos : new MiArrayList<>();
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_contact, parent, false);
        return new ContactViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
        Contacto contacto = contactos.get(position);

        holder.tvNombre.setText(contacto instanceof ContactoPersonal ? (contacto.getNombre() + " " + ((ContactoPersonal)contacto).getApellido()).toUpperCase() : (contacto.getNombre() + " " + ((ContactoEmpresa)contacto).getEmpresa()).toUpperCase());
        holder.tvTipo.setText(contacto instanceof ContactoPersonal ? "Personal" : "Empresa");

        if (!contacto.getFoto().isEmpty()) holder.ivFoto.setImageURI(android.net.Uri.parse(contacto.getFoto()));
        else holder.ivFoto.setImageResource(android.R.drawable.ic_menu_camera);

        if (mostrarBotonesEliminar) holder.itemView.setOnClickListener(null);
        else {
            holder.itemView.setOnClickListener(v -> {
                ContactManager.getInstance().setContactoActual(contacto);
                Intent intent = new Intent(holder.itemView.getContext(), ContactDetailActivity.class);
                holder.itemView.getContext().startActivity(intent);
            });
        }
        holder.btnEliminar.setVisibility(mostrarBotonesEliminar ? View.VISIBLE : View.GONE);
        holder.btnEliminar.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteContact(contacto);
            }
        });
    }

    public void setMostrarBotonesEliminar(boolean mostrar) {
        this.mostrarBotonesEliminar = mostrar;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() { return contactos.size(); }

    public void setContactos(MiArrayList<Contacto> nuevosContactos) {
        this.contactos = nuevosContactos != null ? nuevosContactos : new MiArrayList<>();
        notifyDataSetChanged();
    }

    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvTipo;
        ImageView ivFoto;
        ImageButton btnEliminar;
        public ContactViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvTipo = itemView.findViewById(R.id.tvTipo);
            ivFoto = itemView.findViewById(R.id.ivFoto);
            btnEliminar = itemView.findViewById(R.id.btnEliminar);
        }
    }

    public interface OnContactDeleteListener {
        void onDeleteContact(Contacto contacto);
    }
}