package ec.edu.espol.agenda.view;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.IOException;
import java.util.function.BiFunction;
import ec.edu.espol.agenda.R;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.*;

public class EditContactActivity extends AppCompatActivity {

    private EditText etNombre, etApellido, etEmpresa, etRol;
    private TextView tvFecha;
    private LinearLayout layoutNumeros, layoutEmails, layoutDirecciones, layoutFechas, layoutPersonal, layoutEmpresa;
    private ImageView ivFoto;
    private Button btnGuardar, btnFoto, btnAgregarNumero, btnAgregarEmail, btnAgregarDireccion, btnAgregarFecha;
    private Contacto contactoActual;

    private MiArrayList<Numero> numeros = new MiArrayList<>();
    private MiArrayList<Email> correos = new MiArrayList<>();
    private MiArrayList<Direccion> direcciones = new MiArrayList<>();
    private MiArrayList<Fecha> fechas = new MiArrayList<>();
    private Uri nuevaFotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_form);

        etNombre = findViewById(R.id.etNombre);
        etApellido = findViewById(R.id.etApellido);
        etEmpresa = findViewById(R.id.etEmpresa);
        etRol = findViewById(R.id.etRol);
        layoutNumeros = findViewById(R.id.layoutNumeros);
        layoutEmails = findViewById(R.id.layoutEmails);
        layoutDirecciones = findViewById(R.id.layoutDirecciones);
        layoutFechas = findViewById(R.id.layoutFechas);
        layoutPersonal = findViewById(R.id.layoutPersonal);
        layoutEmpresa = findViewById(R.id.layoutEmpresa);
        ivFoto = findViewById(R.id.ivFoto);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnFoto = findViewById(R.id.btnFoto);
        btnAgregarNumero = findViewById(R.id.btnAgregarNumero);
        btnAgregarEmail = findViewById(R.id.btnAgregarEmail);
        btnAgregarDireccion = findViewById(R.id.btnAgregarDireccion);
        btnAgregarFecha = findViewById(R.id.btnAgregarFecha);
        tvFecha = findViewById(R.id.tvFechas);
        Spinner spinnerTipo = findViewById(R.id.spinnerTipo);
        spinnerTipo.setVisibility(View.GONE);

        contactoActual = ContactManager.getInstance().getContactoActual();
        llenarFormulario(contactoActual);

        btnGuardar.setOnClickListener(v -> guardarCambios());
        btnFoto.setOnClickListener(v -> abrirGaleria());
        btnAgregarNumero.setOnClickListener(v -> agregarCampoDinamico(layoutNumeros, "", ""));
        btnAgregarEmail.setOnClickListener(v -> agregarCampoDinamico(layoutEmails, "", ""));
        btnAgregarDireccion.setOnClickListener(v -> agregarCampoDinamico(layoutDirecciones, "", ""));
        btnAgregarFecha.setOnClickListener(v -> agregarCampoDinamico(layoutFechas, "", ""));
    }

    private void llenarFormulario(Contacto contacto) {
        etNombre.setText(contacto.getNombre());

        if (contacto instanceof ContactoPersonal) {
            layoutPersonal.setVisibility(View.VISIBLE);
            layoutFechas.setVisibility(View.VISIBLE);
            btnAgregarFecha.setVisibility(View.VISIBLE);
            tvFecha.setVisibility(View.VISIBLE);
            etApellido.setVisibility(View.VISIBLE);
            String apellido = ((ContactoPersonal) contacto).getApellido();
            etApellido.setText(apellido != null ? apellido : "");
            fechas = ((ContactoPersonal) contacto).getFechas();
            cargarCamposDinamicos(layoutFechas, fechas);
            layoutEmpresa.setVisibility(View.GONE);
            etEmpresa.setVisibility(View.GONE);
            etRol.setVisibility(View.GONE);
        }
        else if (contacto instanceof ContactoEmpresa) {
            layoutEmpresa.setVisibility(View.VISIBLE);
            etRol.setVisibility(View.VISIBLE);
            String rol = ((ContactoEmpresa) contacto).getRol();
            etRol.setText(rol != null ? rol : "");
            etEmpresa.setVisibility(View.VISIBLE);
            String empresa = ((ContactoEmpresa) contacto).getEmpresa();
            etEmpresa.setText(empresa != null ? empresa : "");
            layoutPersonal.setVisibility(View.GONE);
            etApellido.setVisibility(View.GONE);
            layoutFechas.setVisibility(View.GONE);
            btnAgregarFecha.setVisibility(View.GONE);
            tvFecha.setVisibility(View.GONE);
        }

        numeros = contacto.getNumeros();
        cargarCamposDinamicos(layoutNumeros, numeros);

        correos = contacto.getCorreos();
        cargarCamposDinamicos(layoutEmails, correos);

        direcciones = contacto.getDirecciones();
        cargarCamposDinamicos(layoutDirecciones, direcciones);

        if (contacto.getFoto() != null && !contacto.getFoto().isEmpty()) ivFoto.setImageURI(Uri.parse(contacto.getFoto()));
        else ivFoto.setImageResource(android.R.drawable.ic_menu_camera);
    }


    private <T> void cargarCamposDinamicos(LinearLayout layout, MiArrayList<T> lista) {
        layout.removeAllViews();
        for (T item : lista) {
            if (item instanceof Numero) agregarCampoDinamico(layout, ((Numero) item).getNumero(), ((Numero) item).getDescripcion());
            else if (item instanceof Email) agregarCampoDinamico(layout, ((Email) item).getEmail(), ((Email) item).getDescripcion());
            else if (item instanceof Direccion) agregarCampoDinamico(layout, ((Direccion) item).getDireccion(), ((Direccion) item).getDescripcion());
            else if (item instanceof Fecha) agregarCampoDinamico(layout, ((Fecha) item).getFecha(), ((Fecha) item).getDescripcion());
        }
    }

    private void agregarCampoDinamico(LinearLayout layout, String campo, String descripcion) {
        LinearLayout campoLayout = new LinearLayout(this);
        campoLayout.setOrientation(LinearLayout.HORIZONTAL);

        EditText etCampo = new EditText(this);
        etCampo.setHint("Campo");
        etCampo.setText(campo);
        etCampo.setTag("etCampo");
        etCampo.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        campoLayout.addView(etCampo);

        EditText etDescripcion = new EditText(this);
        etDescripcion.setHint("Descripción");
        etDescripcion.setText(descripcion);
        etDescripcion.setTag("etDescripcion");
        etDescripcion.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        campoLayout.addView(etDescripcion);

        Button btnEliminar = new Button(this);
        btnEliminar.setText("X");
        btnEliminar.setOnClickListener(v -> layout.removeView(campoLayout));
        campoLayout.addView(btnEliminar);

        layout.addView(campoLayout);
    }

    private void guardarCambios() {
        if (etNombre.getText().toString().isEmpty()) {
            Toast.makeText(this, "El nombre es obligatorio.", Toast.LENGTH_SHORT).show();
            return;
        }

        sincronizarListaConVistas(layoutNumeros, numeros, Numero::new);
        sincronizarListaConVistas(layoutEmails, correos, Email::new);
        sincronizarListaConVistas(layoutDirecciones, direcciones, Direccion::new);
        sincronizarListaConVistas(layoutFechas, fechas, Fecha::new);

        contactoActual.setNombre(etNombre.getText().toString());
        if (contactoActual instanceof ContactoPersonal) {
            ((ContactoPersonal) contactoActual).setApellido(etApellido.getText().toString());
            ((ContactoPersonal) contactoActual).setFechas(fechas);
        } else if (contactoActual instanceof ContactoEmpresa) {
            ((ContactoEmpresa) contactoActual).setEmpresa(etEmpresa.getText().toString());
            ((ContactoEmpresa) contactoActual).setRol(etRol.getText().toString());
        }
        contactoActual.setNumeros(numeros);
        contactoActual.setCorreos(correos);
        contactoActual.setDirecciones(direcciones);

        if (nuevaFotoUri != null) {
            contactoActual.setFoto(nuevaFotoUri.toString());
        }

        try {
            ContactManager.getInstance().guardarDatos(new File(getFilesDir(), "contactos.ser"));
            Toast.makeText(this, "Cambios guardados.", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error al guardar los cambios.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }


    private <T> void sincronizarListaConVistas(LinearLayout layout, MiArrayList<T> lista, BiFunction<String, String, T> constructor) {
        lista.clear();
        for (int i = 0; i < layout.getChildCount(); i++) {
            View view = layout.getChildAt(i);
            if (view instanceof LinearLayout) {
                EditText etCampo = view.findViewWithTag("etCampo");
                EditText etDescripcion = view.findViewWithTag("etDescripcion");
                if (etCampo != null && etDescripcion != null) {
                    String valorCampo = etCampo.getText().toString().trim();
                    String valorDescripcion = etDescripcion.getText().toString().trim();
                    if (!valorCampo.isEmpty() || !valorDescripcion.isEmpty()) {
                        T elemento = constructor.apply(valorCampo, valorDescripcion);
                        lista.add(elemento);
                    }
                }
            }
        }
    }

    private void abrirGaleria() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galeriaLauncher.launch(intent);
    }

    private final ActivityResultLauncher<Intent> galeriaLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    nuevaFotoUri = result.getData().getData();
                    mostrarImagenSeleccionada(nuevaFotoUri);
                }
            }
    );

    private void mostrarImagenSeleccionada(Uri uri) {
        nuevaFotoUri = uri;
        if (uri != null) {
            ivFoto.setImageURI(uri);
        } else {
            ivFoto.setImageResource(android.R.drawable.ic_menu_camera);
        }
    }


}