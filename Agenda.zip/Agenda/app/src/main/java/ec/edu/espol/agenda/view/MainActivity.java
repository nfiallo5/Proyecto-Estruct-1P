package ec.edu.espol.agenda.view;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.File;
import java.io.IOException;
import ec.edu.espol.agenda.R;
import ec.edu.espol.agenda.controller.MainController;
import ec.edu.espol.agenda.data.MiArrayList;
import ec.edu.espol.agenda.model.Contacto;
import ec.edu.espol.agenda.model.ContactManager;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewContactos;
    private FloatingActionButton fabAgregarContacto, fabEliminarContactos;
    private ContactAdapter adapter;
    private MainController controller;
    private Spinner spinnerOrdenar;
    private boolean mostrarBotonesEliminar = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cargarContactos();
        controller = new MainController();

        recyclerViewContactos = findViewById(R.id.recyclerViewContactos);
        fabAgregarContacto = findViewById(R.id.fabAgregarContacto);
        fabEliminarContactos = findViewById(R.id.fabEliminarContacto);
        spinnerOrdenar = findViewById(R.id.spinnerOrdenar);

        adapter = new ContactAdapter(ContactManager.getInstance().listarContactos(), this::eliminarContacto);
        recyclerViewContactos.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewContactos.setAdapter(adapter);

        fabAgregarContacto.setOnClickListener(v -> {
            Intent intent = new Intent(this, ContactFormActivity.class);
            startActivity(intent);
            adapter.setMostrarBotonesEliminar(false);
        });

        fabEliminarContactos.setOnClickListener(v -> {
            mostrarBotonesEliminar = !mostrarBotonesEliminar;
            adapter.setMostrarBotonesEliminar(mostrarBotonesEliminar);
        });

        spinnerOrdenar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                MiArrayList<Contacto> contactosOrdenados;
                switch (position) {
                    case 0:
                        contactosOrdenados = controller.obtenerContactosOrdenadosPorTipo(false);
                        break;
                    case 1:
                        contactosOrdenados = controller.obtenerContactosOrdenadosPorTipo(true);
                        break;
                    case 2:
                        contactosOrdenados = controller.obtenerContactosOrdenadosPorNombre();
                        break;
                    case 3:
                        contactosOrdenados = controller.obtenerContactosOrdenadosPorAtributos();
                        break;
                    default:
                        contactosOrdenados = controller.obtenerContactosOrdenadosPorNombre();
                }
                actualizarLista(contactosOrdenados);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        spinnerOrdenar.setSelection(2);
    }

    private void cargarContactos() {
        File file = new File(getFilesDir(), "contactos.ser");
        try {
            ContactManager manager = ContactManager.cargarDatos(file);
            ContactManager.setInstance(manager);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "No hay contactos guardados aún.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        guardarContactos();
    }

    private void guardarContactos() {
        File file = new File(getFilesDir(), "contactos.ser");
        try {
            ContactManager.getInstance().guardarDatos(file);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al guardar los contactos.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiArrayList<Contacto> contactosOrdenados = controller.obtenerContactosOrdenadosPorNombre();
        actualizarLista(contactosOrdenados);
        if (contactosOrdenados.isEmpty()) spinnerOrdenar.setVisibility(View.GONE);
        else {
            spinnerOrdenar.setVisibility(View.VISIBLE);
            spinnerOrdenar.setSelection(2);
        }
    }

    private void actualizarLista(MiArrayList<Contacto> contactosOrdenados) {
        adapter.setContactos(contactosOrdenados);
        adapter.notifyDataSetChanged();
        if (contactosOrdenados.isEmpty()) spinnerOrdenar.setVisibility(View.GONE);
        else spinnerOrdenar.setVisibility(View.VISIBLE);
    }


    private void eliminarContacto(Contacto contacto) {
        ContactManager.getInstance().eliminarContacto(contacto);
        guardarContactos();
        actualizarLista(ContactManager.getInstance().listarContactos());
    }
}