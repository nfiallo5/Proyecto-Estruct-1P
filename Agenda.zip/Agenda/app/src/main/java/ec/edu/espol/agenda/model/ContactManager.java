package ec.edu.espol.agenda.model;

import java.io.*;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

import ec.edu.espol.agenda.data.MiArrayList;

public class ContactManager implements Serializable {

    private static ContactManager instance;
    private MiArrayList<Contacto> contactos;
    private static final long serialVersionUID = 1L;
    private transient Contacto contactoActual;

    private ContactManager() { this.contactos = new MiArrayList<>(); }

    public static synchronized ContactManager getInstance() {
        if (instance == null) instance = new ContactManager();
        return instance;
    }

    public static void setInstance(ContactManager manager) { instance = manager; }

    public boolean agregarContacto(Contacto contacto) {
        if (contactos.contains(contacto)) {
            System.out.println("Contacto ya existe: " + contacto.getNombre());
            return false;
        }
        contactos.add(contacto);
        System.out.println("Contacto agregado: " + contacto.getNombre());
        return true;
    }

    public MiArrayList<Contacto> listarContactos() { return contactos; }

    public void guardarDatos(File file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(this);
            System.out.println("Contactos guardados exitosamente en: " + file.getAbsolutePath());
        }
    }

    public static ContactManager cargarDatos(File file) throws IOException, ClassNotFoundException {
        if (!file.exists()) {
            System.out.println("Archivo no encontrado, creando una nueva instancia de ContactManager.");
            return new ContactManager();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            ContactManager manager = (ContactManager) ois.readObject();
            System.out.println("Contactos cargados exitosamente desde: " + file.getAbsolutePath());
            return manager;
        }
    }

    public boolean eliminarContacto(Contacto contacto) {
        Iterator<Contacto> iterator = contactos.iterator();
        while (iterator.hasNext()) {
            Contacto otroContacto = iterator.next();
            if (contacto.equals(otroContacto)) {
                iterator.remove();
                System.out.println("Contacto eliminado: " + contacto.getNombre());
                return true;
            }
        }
        return false;
    }

    public void setContactoActual(Contacto contacto) { this.contactoActual = contacto; }

    public Contacto getContactoActual() { return contactoActual; }

    public MiArrayList<Contacto> ordenarPorNombre() {
        Queue<Contacto> sorted = new PriorityQueue<>((t1, t2) -> t1.getNombre().compareTo(t2.getNombre()));
        sorted.addAll(contactos);
        return convertirALista(sorted);
    }

    public MiArrayList<Contacto> ordenarPorTipo(boolean descendente) {
        Queue<Contacto> sorted = new PriorityQueue<>((t1, t2) -> descendente ? t2.getTipo().compareTo(t1.getTipo()) : t1.getTipo().compareTo(t2.getTipo()));
        sorted.addAll(this.contactos);
        return convertirALista(sorted);
    }

    public MiArrayList<Contacto> ordenarPorCantidadAtributos() {
        Queue<Contacto> sorted = new PriorityQueue<>((t1, t2) -> t1.getCantidadAtributos().compareTo(t2.getCantidadAtributos()));
        sorted.addAll(this.contactos);
        return convertirALista(sorted);
    }

    private MiArrayList<Contacto> convertirALista(Queue<Contacto> queue) {
        MiArrayList<Contacto> lista = new MiArrayList<>();
        while (!queue.isEmpty()) lista.add(queue.poll());
        return lista;
    }
}
