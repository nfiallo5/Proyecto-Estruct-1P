package ec.edu.espol.agenda.model;

import ec.edu.espol.agenda.data.MiArrayList;

public class ContactoPersonal extends Contacto {
    private String apellido;
    private MiArrayList<Fecha> fechas;

    public ContactoPersonal() {
        super();
        this.fechas = new MiArrayList<>();
    }

    public String getApellido() { return apellido; }

    public void setApellido(String apellido) { this.apellido = apellido; }

    public MiArrayList<Fecha> getFechas() { return fechas; }

    public void setFechas(MiArrayList<Fecha> fechas) { this.fechas = fechas; }

    @Override
    public String getTipo() { return "Personal"; }

    @Override
    public int compareTo(Contacto contacto2){
        int nombreComparacion = this.getNombre().compareTo(contacto2.getNombre());
        if (contacto2 instanceof ContactoPersonal) {
            ContactoPersonal otroPersonal = (ContactoPersonal) contacto2;
            int apellidoComparacion = this.apellido.compareTo(otroPersonal.getApellido());
            return (nombreComparacion != 0) ? nombreComparacion : apellidoComparacion;
        }
        return nombreComparacion;
    }
}